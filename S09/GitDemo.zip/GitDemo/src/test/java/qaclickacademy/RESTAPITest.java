package qaclickacademy;

import org.testng.annotations.Test;
//rahulonlinetutor@gmail.com
public class RESTAPITest {

	@Test
	public void postJira()
	{
		System.out.println("postJira");
		System.out.println("postJira2");
		System.out.println("postJira3");
		//feere
		//ffgf
		//fgf
		System.out.println("postJira4");
		System.out.println("postJira5");
		System.out.println("postJira6");
		System.out.println("postJira7");
		
		
		
		
		
		
	}
	
	@Test
	public void deleteTwitter()
	{
		System.out.println("deleteTwitter");
		
		
	}
	@Test
	public void deleteTwitter12()
	{
		System.out.println("deleteTwddtter");
		
		
	}
}
