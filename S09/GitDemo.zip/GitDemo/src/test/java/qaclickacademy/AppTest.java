package qaclickacademy;

public class AppTest {

}
