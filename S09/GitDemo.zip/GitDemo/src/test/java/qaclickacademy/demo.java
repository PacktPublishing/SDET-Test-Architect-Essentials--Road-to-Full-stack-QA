package qaclickacademy;

public class demo {

}
